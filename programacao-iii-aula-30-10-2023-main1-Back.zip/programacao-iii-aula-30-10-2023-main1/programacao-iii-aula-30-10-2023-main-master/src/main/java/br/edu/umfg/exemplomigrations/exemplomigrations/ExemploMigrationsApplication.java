package br.edu.umfg.exemplomigrations.exemplomigrations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploMigrationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploMigrationsApplication.class, args);
	}

}
