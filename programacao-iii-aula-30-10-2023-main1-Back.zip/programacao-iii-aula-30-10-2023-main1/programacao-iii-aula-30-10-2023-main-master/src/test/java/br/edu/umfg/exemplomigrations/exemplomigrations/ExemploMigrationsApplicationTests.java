package br.edu.umfg.exemplomigrations.exemplomigrations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploMigrationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
